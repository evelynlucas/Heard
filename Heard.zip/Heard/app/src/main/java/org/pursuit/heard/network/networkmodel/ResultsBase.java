package org.pursuit.heard.network.networkmodel;

import java.util.List;

public class ResultsBase {

    private List<ArtistModel> results;

    public List<ArtistModel> getResults() {
        return results;
    }
}
