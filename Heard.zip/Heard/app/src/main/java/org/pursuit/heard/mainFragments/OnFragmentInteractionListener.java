package org.pursuit.heard.mainFragments;

import android.os.Bundle;

import org.pursuit.heard.database.UserProfile;

public interface OnFragmentInteractionListener {

    void openAddArtistFragment(String username);

    void loginToMainFragment(String username);

}
